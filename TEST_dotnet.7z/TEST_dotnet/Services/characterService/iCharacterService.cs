using System.Collections.Generic;
using TEST_dotnet.models;

namespace TEST_dotnet.Services.characterService
{
    public interface iCharacterService
    {
        List<Character> GetAllCharacters();

        Character GetCharacterById(int id);

        List<Character> AddCharacter(Character newCharacter);
    }
}