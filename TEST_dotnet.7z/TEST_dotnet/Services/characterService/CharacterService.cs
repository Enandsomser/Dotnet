using System.Collections.Generic;
using System.Linq;
using TEST_dotnet.models;

namespace TEST_dotnet.Services.characterService
{
    public class CharacterService : iCharacterService
    {
         private static List<Character> Balls = new List<Character>
        {
            new Character(),
            new Character { Id = 1, Name = "Glanga" }
        };
        public List<Character> AddCharacter(Character newCharacter)
        {
            Balls.Add(newCharacter);
            return Balls;
        }

        public List<Character> GetAllCharacters()
        {
            return Balls;
        }

        public Character GetCharacterById(int id)
        {
             return Balls.FirstOrDefault(c => c.Id == id);
        }
    }
}